# data manipulation
import json
from decimal import Decimal
import pandas as pd
import numpy as np


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)


def calculate_average_amount_spent(data_frame):

    # sums the total amount spent on gold products
    sum_gold = data_frame['mnt_gold_prods'].sum()

    # sums the total amount spent on fish products
    sum_fish = data_frame['mnt_fish_products'].sum()

    # sums the total amount spent on meat products
    sum_meat = data_frame['mnt_meat_products'].sum()

    # sums the total amount spent on fruits products
    sum_fruit = data_frame['mnt_fruits'].sum()

    # sums the total amount spent on sweet products
    sum_sweet = data_frame['mnt_sweet_products'].sum()

    # sums the total amount spent on wine products
    sum_wine = data_frame['mnt_wines'].sum()

    # sums the totals
    total_sum = sum_gold + sum_fish + sum_meat + sum_sweet + sum_wine

    # calculates the average amount each customer spend
    average_amount_spent = total_sum/data_frame.shape[0]

    return average_amount_spent


def prepare_data_for_calculation(probs, threshold):

    # stores the responses probabilities given by the algorithm
    df_responses = pd.DataFrame(probs, columns=['prob_not_convert', 'prob_convert'])

    # converts to float dtype
    threshold = float(threshold)

    # calculates if convert or not based on the given threshold
    df_responses['conversion'] = df_responses['prob_convert'].apply(lambda x: 1 if x >= (1 - threshold) else 0)

    return df_responses


def calculate_total_expected_revenue(data_frame, probs, threshold, medium_cost):

    # converts to float dtype
    medium_cost = float(medium_cost)

    # calculates the average amount spent
    average_amount_spent = calculate_average_amount_spent(data_frame)

    # prepares the data frame based on the probabilities and given threshold
    responses = prepare_data_for_calculation(probs, threshold)

    # calculates the expected number of customers to convert
    customers_expected_to_convert = responses['conversion'].sum()

    # calculates the expected revenue
    total_revenue = (customers_expected_to_convert * average_amount_spent) - (customers_expected_to_convert * medium_cost)

    return round(total_revenue, 2)


def get_converted_customers(data_frame, probs, threshold):

    # prepares the data frame based on the probabilities and given threshold
    responses = prepare_data_for_calculation(probs, threshold)

    # gets only the customers that are expected to convert (conversion == 1)
    df_converted_customers = data_frame.join(responses, on=data_frame.index,
                                             how='left').query("conversion == 1")

    # drops unuseful columns
    df_converted_customers.drop(['prob_not_convert', 'prob_convert'], axis=1, inplace=True)

    # reorders the columns
    columns_order = ['id', 'year_birth', 'education', 'marital_status', 'income',
                     'kid_home', 'teen_home', 'dt_customer', 'recency',
                     'mnt_wines', 'mnt_fruits', 'mnt_meat_products',
                     'mnt_fish_products', 'mnt_sweet_products', 'mnt_gold_prods',
                     'num_deals_purchases', 'num_web_purchases', 'num_catalog_purchases',
                     'num_store_purchases', 'num_web_visits_month',
                     'complain', 'conversion']

    df_converted_customers = df_converted_customers[columns_order]

    # rounds the numeric columns
    df_converted_customers = df_converted_customers.round(2)

    return df_converted_customers
