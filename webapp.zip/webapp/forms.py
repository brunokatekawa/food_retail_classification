# forms
from flask_wtf import FlaskForm
from flask_wtf.file import FileField
from wtforms import SubmitField
from wtforms.fields.html5 import DecimalRangeField
from wtforms.validators import DataRequired


class MarketingParametersForm(FlaskForm):
    medium_cost = DecimalRangeField('Medium cost ($)', id='medium-cost-slider', default=0)
    threshold = DecimalRangeField('Threshold', id='threshold-slider', default=0)
    file = FileField('CSV File', id='csv-file', validators=[DataRequired()])
    submit = SubmitField('Calculate')
