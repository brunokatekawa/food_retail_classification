# data manipulation
import json
import os
import pandas as pd
import openpyxl
from utils import DecimalEncoder, calculate_total_expected_revenue, get_converted_customers

# routes and page rendering
from flask import Flask, render_template, session, redirect, url_for

# form
from forms import MarketingParametersForm

# machine learning
from preprocessors import Pipeline

# creates the app and sets configs
app = Flask(__name__)
app.config['SECRET_KEY'] = 'ifoodmktapp'

# instantiates the data pipeline
pipeline = Pipeline()


@app.route('/', methods=['GET', 'POST'])
def index():
    # creates an instance of the form
    form = MarketingParametersForm()

    # if form is valid on submission
    if form.validate_on_submit():
        # gets the threshold selected by the user
        session['threshold'] = json.dumps(form.threshold.data, cls=DecimalEncoder)

        # gets the medium cost selected by the user
        session['medium_cost'] = json.dumps(form.medium_cost.data, cls=DecimalEncoder)

        # stores the CSV file as a pandas DataFrame
        df_raw = pd.read_csv(form.file.data)

        # makes the predcitions
        predictions = pipeline.predict(df_raw)

        # calculates the total expected revenue
        total_expected_revenue = calculate_total_expected_revenue(df_raw, predictions, session['threshold'], session['medium_cost'])

        # sets the value to a session var
        session['total_expected_revenue'] = "${:,.2f}".format(total_expected_revenue)

        # gets the list of customers that converted
        converted_customers = get_converted_customers(df_raw, predictions, session['threshold'])

        # saves the list
        converted_customers.to_excel("static/converted_customers.xlsx", sheet_name="Customers")

        return redirect(url_for("results"))

    return render_template("index.html", form=form)


@app.route('/results')
def results():
    return render_template("results.html")


if __name__ == "__main__":
    port = os.environ.get('PORT', 5000)
    app.run(host='0.0.0.0', port=port)
