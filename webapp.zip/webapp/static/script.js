
function updateThreshold(input_value) {
  document.getElementById('selected-threshold').value = input_value;
}

function updateMediumCost(input_value) {
  document.getElementById('selected-medium-cost').value = input_value;
}

function resetForm() {
  // resets slides on page load or refresh
  document.getElementById('threshold-slider').value = 0;
  document.getElementById('selected-threshold').value = 0;
  document.getElementById('selected-medium-cost').value = 0;

  // resets the csv file to be uploaded
  document.getElementById('csv-file').value = null;

  console.log('form reseted')
}

window.onload = function () {
  // resets slides on page load or refresh
  document.getElementById('threshold-slider').value = 0;

  // resets slides on page load or refresh
  document.getElementById('medium-cost-slider').value = 0;

  // resets the csv file to be uploaded
  document.getElementById('csv-file').value = null;

  console.log("all loaded")
}