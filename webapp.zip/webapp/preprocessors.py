# data manipulation
import pickle
import pandas as pd
import numpy as np
import datetime

# data transformation
from sklearn.preprocessing import MinMaxScaler


class Pipeline(object):

    def __init__(self):
        # sets home path
        self.home_path = ''

        # loads model
        self.model = pickle.load(
            open(self.home_path + 'model/calibrated_best_model_clf.pkl', 'rb'))

        # loads scaler
        self.scaler = pickle.load(
            open(self.home_path + 'parameter/min_max_scaler.pkl', 'rb'))

    # makes the feature engineering
    def make_feature_engineering(self, input_data):

        # makes a copy
        data = input_data.copy()

        # gets the current time
        now = datetime.datetime.now()

        #------------#
        # PERSON AGE #

        # gets the current year
        current_year = now.year

        # creates person age
        data['person_age'] = current_year - data['year_birth']

        #---------------------------#
        # CUSTOMER ENROLLMENT TIME  #

        # calculates the time difference
        time_diff = now - data['dt_customer']

        # resets the index
        time_diff.index = np.arange(len(time_diff))

        # converts the difference to years
        time_diff_years = [time_diff[element].days / 365 for element in np.arange(len(time_diff))]

        # creates column for enrollment time
        data['enrollment_time'] = time_diff_years

        #--------------------#
        # DECOMPOSING DATES  #

        # gets customer enrollment year
        data['dt_enrollment_year'] = data['dt_customer'].dt.year

        # gets customer enrollment month
        data['dt_enrollment_month'] = data['dt_customer'].dt.month

        # gets customer enrollment day
        data['dt_enrollment_day'] = data['dt_customer'].dt.day

        return data

    # separates data types in different sets
    def make_data_separation(self, input_data):

        # makes a copy
        data = input_data.copy()

        # drops the unuseful columns
        data.drop(['id', 'dt_customer', 'z_cost_contact', 'z_revenue'], axis=1, inplace=True)

        # creates a data set for binary attributes
        binary_vars = ['accepted_cmp1', 'accepted_cmp2', 'accepted_cmp3',
                       'accepted_cmp4', 'accepted_cmp5', 'complain']
        binary_attributes = data[binary_vars]

        # gets only numerical attributes excluding binary ones
        num_attributes = data.drop(binary_vars, axis=1).select_dtypes(include=['int64', 'float64'])

        # gets only categorical attributes
        cat_attributes = data.select_dtypes(exclude=['int64', 'float64', 'datetime64[ns]'])

        return num_attributes, cat_attributes, binary_attributes

    # makes the numerical features scaling
    def make_scaling(self, input_data):

        # makes a copy
        data = input_data.copy()

        # fits scaler to data and transform it
        data_scaled = self.scaler.transform(data)

        # converts to DataFrame for later concat
        data_scaled = pd.DataFrame(data_scaled, columns=data.columns)

        return data_scaled

    # makes the categorical features encoding
    def make_categorical_encoding(self, input_data):

        # makes a copy
        data = input_data.copy()

        #-----------#
        # EDUCATION #

        # creates a dictionary from value counts
        count_dict_education = data['education'].value_counts().to_dict()

        # stores values as DataFrame
        df_count_education = pd.DataFrame(count_dict_education.items(), columns=['Value', 'Count'])

        # calculates the frequency for each value
        df_count_education['frequency'] = df_count_education['Count'] / df_count_education['Count'].sum()

        # gets a dictionary for the frequency
        frequency_education = df_count_education.set_index('Value').to_dict()['frequency']

        #----------------#
        # MARITAL STATUS #

        # creates a dictionary from value counts
        count_dict_marital = data['marital_status'].value_counts().to_dict()

        # stores values as DataFrame
        df_count_marital = pd.DataFrame(count_dict_marital.items(), columns=['Value', 'Count'])

        # calculates the frequency for each value
        df_count_marital['frequency'] = df_count_marital['Count'] / df_count_marital['Count'].sum()

        # gets a dictionary for the frequency
        frequency_marital = df_count_marital.set_index('Value').to_dict()['frequency']

        #-------------------------#
        # STORES THE ENCODED DATA #

        # creates an empty DataFrame
        data_encoded = pd.DataFrame()

        # creates a column for frequency
        data_encoded['education'] = data['education'].map(frequency_education)
        data_encoded['marital_status'] = data['marital_status'].map(frequency_marital)

        return data_encoded

        #######################
        # DATA TRANSFORMATION #
        #######################

        # creates features, scales and encodes the data

    def transform(self, input_data):

        # makes a copy
        data = input_data.copy()

        # converts dt_customer to datetime dtype
        data['dt_customer'] = pd.to_datetime(data['dt_customer'])

        # makes the feature engineering
        data_fe = self.make_feature_engineering(data)

        # separates data types
        numerical_data, categorical_data, binary_data = self.make_data_separation(data_fe)

        # makes the numerical features scaling
        num_data_scaled = self.make_scaling(numerical_data)

        # makes the categorical features encoding
        cat_data_encoded = self.make_categorical_encoding(categorical_data)

        # unites the scaled data with encoded data
        data_prep = pd.concat([num_data_scaled, binary_data, cat_data_encoded], axis=1)

        return data_prep

    # makes the transformations and predictions
    def predict(self, input_data):

        # makes the data transformation
        transformed_data = self.transform(input_data)

        # makes the predictions
        predictions = self.model.predict_proba(transformed_data)

        return predictions
